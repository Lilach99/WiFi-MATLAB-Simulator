function [timesList, eventsList] = insertInOrder(timesList, eventsList, newTime, newEvent)
    % inserts the newEvent and newTime to the lists, according to the sort
    % order of times
    %   gets the new time and new event and the arrays, and returns the
    %   updated arrays with the new values in the right places
    eventsList{size(eventsList, 2) + 1} = newEvent;
    timesList{size(timesList, 2) + 1} = newTime;
    [~,TimeSort]=sort(cell2mat(timesList)); %Get the sorted order of times
    eventsList = eventsList(TimeSort);
end