
function [SimTime, EffectiveThpt1, EffectiveThpt2, CollPer, PacketsTimeLine] = comSim(InterArrival, PacketsA, PacketsB, LinkLen, ST, SIFS, AckSize, AckDur, AckTO, NumRet, LinkRate, TranRateA, TranRateB, PLossPer, FinishTime)
    
    %Simulates the link, according to the input parameters
    %   Station_ wants to send "packets_" in "tranRate_", the IFS times and 
    %   the CSMA variables are as specified in the input variables.
    %   The function returns the total time of the simulation, the
    %   effective link throughput and the percentage of collided packets.
    %   It also plots some graphs regarding to the transmission times of
    %   the packets.
    
    fprintf('Simulator started...');
 
    c = 299704644.54; % light speed in air in m/sec
    curTime = 0; % time in simulation, in microseconds
    TimeA = 0;
    TimeB = 0;
    DIFS = SIFS + 2*ST; 
    collCnt = 0; % collisions counter
    APD = (LinkLen*1000)\c; % air propagation delay in seconds
    rndRange = 100; % the range of random first sending time, in microseconds
    
    % 2*1 arrays for stations data
    % empty queues for the packets the devices want to send
    queues = {[], []}; 
    % the next packets to send for each device
    nextSend = [1, 1];
    packetsToSend = [PacketsA, PacketsB];
    tranTimes = [0, 0];
    nRetries = [0, 0];
    backoffs = [3000, 3000]; % 3000 is an idnication for no backoff
    finTimes = [-1, -1]; % the next finish transmitting times of the stations
    
    % event: struct which contains the fields: type, time, station
    % first event for station 1
    e1.type = 'GEN_PACK';
    e1.time = randi(rndRange);
    e1.station = 1;
    % first event for station 2
    e2.type = 'GEN_PACK';
    e2.time = randi(rndRange);
    e2.station = 2;
    
    % insert events to the data structure, which we have to maintain sorted
    % accordding to the 'time' field. 
    % here the way is keeping a seperate sorted times vector and sorting 
    % the events array according to it...
    eventsList = {e1, e2};
    eventTimes = {e1.time, e2.time};
    [~,TimeSort]=sort(cell2mat(eventTimes)); %Get the sorted order of times
    eventsList = eventsList(TimeSort);
 
    mediumState = 'idle';
    CWmin = 1;
    CWmax = 1023;
    cwnd = 1; % the current contention window (the backoff range)
    
    % run this loop until the simulation time ends or both of the stations
    % finished transmitting
    while(((nextSend(1) ~= size(PacketsA, 2)) || (nextSend(1) ~= size(PacketsB, 2))) & (curTime <= FinishTime))
        % find the last event happens now
        curTime = eventsList{1}.time;
        i = 1;
        time = curTime;
        while((time == curTime) && (i+1 < size(eventsList, 2)))
            time = eventsList{i+1}.time; % assume there are at least 2 events int the array
            i = i+1;
        end 
        i = i-1; % we increased i one time extra
        currentEvents = eventsList(1:i);
        
        for ind=1:i % foreach event in currentEvents
            event = currentEvents{ind}; % the struct
            station = event.station;
            % handle event
            switch event.type
                
                case 'GEN_PACK'
                    queues{station, nextSend(station)} = packetsToSend(station, nextSend(station));
                    % create new 'GEN_PACKET' event after IAT
                     e.type = 'GEN_PACK';
                     e.time = curTime + InterArrival;
                     e.station = station;
                     [eventTimes, eventsList]=insertInOrder(eventTimes, eventsList, e.time, e); % insert the new event and its time to the corresponding arrays in the right order
                     if (size(queues{station}, 2) == 1)
                         % this is the only packet in the queue so we
                         % create a 'CSMA_START' event 1 microsecond later
                         e.type = 'CSMA_START';
                         e.time = curTime + 1;
                         e.station = station;
                         [eventTimes, eventsList]=insertInOrder(eventTimes, eventsList, e.time, e); % insert the new event and its time to the corresponding arrays in the right order
                     end
                     
                case 'CSMA_START'
                    % calculate the transmission time of the packet and
                    % insert it to the corresponding cell in the tranTimes
                    % array
                    tranTimes(station) = (queues{station, nextSend(station)})/TranRateA;
                    if (strcmp(mediumState,'idle')) %strcmp returns true if the strings are identical
                         % the medium is free, so we create a 'PACKET_TRAN'
                         % event after DIFS time
                         e.type = 'PACKET_TRAN';
                         e.time = curTime + DIFS; 
                         e.station = station;
                         [eventTimes, eventsList]=insertInOrder(eventTimes, eventsList, e.time, e); % insert the new event and its time to the corresponding arrays in the right order
                    end
                    if(strcmp(mediumState,'busy'))
                         % the medium is busy, so we create a 'DEFER'
                         % event by the end of the current transmission
                         e.type = 'DEFER';
                         e.time = curTime + finTimes(3-station) + SIFS + APD + AckDur; % the other station's finish time, plus the ACKking procedure of this station
                         e.station = station;
                         [eventTimes, eventsList]=insertInOrder(eventTimes, eventsList, e.time, e); % insert the new event and its time to the corresponding arrays in the right order
                    end
                    
                case 'DEFER'
                    if (strcmp(mediumState,'idle')) % it should be the situation...
                       % create a 'BACKOFF_START' event for this station
                       % after DIFS time
                       e.type = 'BACKOFF_START';
                       e.time = curTime + DIFS;
                       e.station = station;
                       [eventTimes, eventsList]=insertInOrder(eventTimes, eventsList, e.time, e); % insert the new event and its time to the corresponding arrays in the right order 
                    end
                    
                case 'BACKOFF_START'
                    backoffs(station) = ST*rand(0, cwnd); % randomize the backoff time and insert it to the backoffs array
                    % create a 'BACKOFF_DEC' event within the smallest
                    % backoff time (the station who chose it will "win"
                    e.type = 'BACKOFF_DEC';
                    e.time = curTime + min(backoffs);
                    e.station = min(backoffs); % only in this event, the "station" fiels contains the time we have to decrease from the backoff!!
                    [eventTimes, eventsList]=insertInOrder(eventTimes, eventsList, e.time, e); % insert the new event and its time to the corresponding arrays in the right order 
                       
                case 'BACKOFF_DEC'
                    cnt = 0; % counts the number of stations whose backoffs turns to zero at the moment
                    for j=1:2
                        if(backoffs(j)~=3000) % if there is a relevant backoff
                            backoffs(j) = backoffs(j)-event.station;
                        end
                        if(backoffs(j)==0) 
                            cnt = cnt + 1;
                            % backoff time ended! create a 'PACKET_TRAN'
                            % event 1 microsecind later
                            e.type = 'PACKET_TRAN';
                            e.time = curTime + 1;
                            e.station = station; % only in this event, the "station" fiels contains the time we have to decrease from the backoff!!
                            [eventTimes, eventsList]=insertInOrder(eventTimes, eventsList, e.time, e); % insert the new event and its time to the corresponding arrays in the right order 
                        end
                    end
                    if(cnt > 1)
                        % collision occurred!
                        mediumState = 'collison';
                        collCnt = collCnt + 2; % both of the packets collided
                    else % so cnt == 1, so station 3-e.station should stop its backoff
                        e.type = 'BACKOFF_STOP'; % TODO: think more about it... we also have to delete the 'DEC_BACKOFF' event corresponding to this station!
                        e.time = curTime + 1;
                        e.station = 3-e.station;
                        [eventTimes, eventsList]=insertInOrder(eventTimes, eventsList, e.time, e); % insert the new event and its time to the corresponding arrays in the right order 
                    end
 
                case 'BACKOFF_STOP'
                    % create 'BACKOFF_CONT' after the finish time
                    e.type = 'BACKOFF_CONT'; 
                    e.time = finishTime(3-station) + SIFS + APD + AckDur;
                    e.station = station;
                    [eventTimes, eventsList]=insertInOrder(eventTimes, eventsList, e.time, e); % insert the new event and its time to the corresponding arrays in the right order 
                
                case 'BACKOFF_CONT'
                    % continue form the same backoff counter value, without
                    % randomizing a new one
                    e.type = 'BACKOFF_DEC';
                    e.time = curTime + min(backoffs);
                    e.station = min(backoffs); % only in this event, the "station" fiels contains the time we have to decrease from the backoff!!
                    [eventTimes, eventsList]=insertInOrder(eventTimes, eventsList, e.time, e); % insert the new event and its time to the corresponding arrays in the right order 
                    
                case 'PACKET_TRAN'
                    % we have to check whether or not a collision occurred
                    % here
                    % in case of COLLISSION:
                    if(strcmp(mediumState, 'collision')) % in case of collision, both events of transmission will get here when the medium state is 'collision'
                        % create a 'ACK_MISS' event for this station after ACK TO expires
                        e.type = 'ACK_MISS';
                        e.time = curTime + AckTO;
                        e.station = station;
                        [eventTimes, eventsList]=insertInOrder(eventTimes, eventsList, e.time, e); % insert the new event and its time to the corresponding arrays in the right order
                    else
                        % in case of NO COLLISSION:
                        mediumState = 'busy';
                        % create an 'ACK_TRAN' event for the second station
                        % within packet transmisson time + propagation delay
                        e.type = 'ACK_TRAN';
                        e.time = curTime + APD + tranTimes(station) + SIFS; % wait SIFS before sending the ACK - ctrl packet!
                        e.station = 3 - station; % takes us to the other station: 3-2=1; 3-1=2
                        [eventTimes, eventsList]=insertInOrder(eventTimes, eventsList, e.time, e); % insert the new event and its time to the corresponding arrays in the right order
                    end
                    
                    % anyway, we update the finish transmission time 
                    % (the time when the medium will be free)
                    finTimes(station) = curTime + APD + tranTimes(station);
                    % anyway, we create a 'MED_FREE' event within packet 
                    % transmisson time + propagation delay
                    e.type = 'MED_FREE';
                    e.time = finTimes(station);
                    e.station = station;
                    [eventTimes, eventsList]=insertInOrder(eventTimes, eventsList, e.time, e); % insert the new event and its time to the corresponding arrays in the right order
                    
                    if (size(queues{station}, 2) > 1)
                         % there are more packets to send in the queue, so we
                         % create a 'CSMA_START' event 1 microsecond later
                         e.type = 'CSMA_START';
                         e.time = curTime + 1;
                         e.station = station;
                         [eventTimes, eventsList]=insertInOrder(eventTimes, eventsList, e.time, e); % insert the new event and its time to the corresponding arrays in the right order
                     end

                case 'ACK_TRAN'
                    % assume no collision will occur now... the station is
                    % waiting for this ACK 
                    mediumState = 'busy';
                    
                    % create a 'ACK_REC' event for the second station
                    % within ackDur + propagation delay
                    e.type = 'ACK_REC';
                    e.time = curTime + APD + AckDur; % TODO: find the ackDur
                    e.station = 3 - station;
                    [eventTimes, eventsList]=insertInOrder(eventTimes, eventsList, e.time, e); % insert the new event and its time to the corresponding arrays in the right order
                     
                    % create a 'MED_FREE' event within packet transmisson 
                    % time + propagation delay
                    e.type = 'MED_FREE';
                    e.time = curTime + APD + AckDur;
                    e.station = station;
                    [eventTimes, eventsList]=insertInOrder(eventTimes, eventsList, e.time, e); % insert the new event and its time to the corresponding arrays in the right order
                    
                case 'MED_FREE'
                    if(curTime > max(finTimes)) % insure both of the stations have finished transmitting now
                        mediumState = 'idle';
                    end 
               
                case 'ACK_MISS'
                    cwnd = min(cwnd*2, CWmax);
                    nRetries(station) = nRetries(station)+1;
                    if (nRetries(station) < NumRet) % we can still try again
                         e.type = 'CSMA_START';
                         e.time = curTime + 1;
                         e.station = station;
                         [eventTimes, eventsList]=insertInOrder(eventTimes, eventsList, e.time, e); % insert the new event and its time to the corresponding arrays in the right order
                    else
                        % no more retries, throw packet and zero retries
                        % counter
                        queues{station} = queues{station}(2:nextSend(station));
                        nRetries(station) = 0;
                    end
                    
                case 'ACK_REC'
                    nextSend(station) = nextSend(station)+1;
                    queues{station} = queues{station}(2:nextSend(station)); % removing the successfully sent packet (which is the first in the queue) from the queue
                    nRetries(station) = 0; % zero the numRetries variable for this station, because we are about to start transmitting a new packet
                
                otherwise
                    fprintf('invalid event!') % we should not reach here...
            end
            eventsList(i) = []; % delete the whole cell of the handled event from the list
            eventTimes(i) = [];
                
        end
        
        
   
     
        
    end
    % End of simulation
    % Output calculations:
    SimTime = curTime; % in microseconds
    EffectiveThpt1 = sum(PacketsA, "all")/(TimeA*(10^(-6)));
    EffectiveThpt2 = sum(PacketsB, "all")/(TimeB*(10^(-6)));
    CollPer = collCnt/(size(PacketsA, 2)+size(PacketsB, 2));
end



%  % assume, for now, that the transmission rate is the same for both
%         % stations
%         
%         
%         if(1) %medium is free to use
%             backoff = ST*rand(0, cwnd); % randomize the backoff time
%             if(packet == AckSize) % Ack
%                 timer = backoff + SIFS;
%                 tranDur = AckDur;
%             else % Data packet
%                 timer = backoff + SIFS + 2*ST; % DIFS = SIFS + 2*SlotTime
%                 tranDur = packet/TranRateA ; % transmission duration = [packet size] / [transmission rate]
%             end
%         end
%         
%         if(1) %collison occurred
%             collCnt = collCnt + 1; % count the collision
%             cwnd = cwnd*2; % multiple the cwnd size
%             if(cwnd > CWmax) 
%                 cwnd = CWmin; % tancate cyclicly if it's needed
%             end
%         end
%         
%         % update indices, curTime and TimeA or TimeB, which should count
%         % the tital time it took to send the packets for each station
%         
%     end
%     if(index1 ~= size(PacketsA, 2)) % station 1 has not finished yet
%     
%     else %station 2 has not finished yet
%         
%     end 
    